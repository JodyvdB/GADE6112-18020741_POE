﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResourceBuilding : MonoBehaviour
{

    [SerializeField] string team;
    public float remainingResources = 100;
    [SerializeField] float maxHealth;
    [SerializeField] float health;

    public GameObject healthBarUI;
    public Slider slider;
    public Text txt;

    // Start is called before the first frame update
    void Start()
    {
        health = maxHealth;
        slider.value = health;
    }

    // Update is called once per frame
    void Update()
    {
        txt.text = "Resources: " + remainingResources;
        slider.value = health;

        if (health < maxHealth)
        {
            healthBarUI.SetActive(true);
        }

        if (health <= 0)
        {
            Destroy(this);
        }

        if (health >= maxHealth)
        {
            health = maxHealth;
        }
    }

} // Class end
