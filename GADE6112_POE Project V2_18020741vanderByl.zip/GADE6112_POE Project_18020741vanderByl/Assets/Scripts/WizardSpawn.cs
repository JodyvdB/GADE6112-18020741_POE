﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WizardSpawn : MonoBehaviour
{

    [SerializeField] GameObject unit;
    [SerializeField] GameObject spawnPoint;
    [SerializeField] float maxHealth;
    [SerializeField] float health;

    public GameObject healthBarUI;
    public Slider slider;

    private int counter = 0;

    // Start is called before the first frame update
    void Start()
    {
        health = maxHealth;
        slider.value = health;

        StartCoroutine(spawnUnits());

        IEnumerator spawnUnits()
        {
            yield return new WaitForSeconds(Random.Range(5f, 10f));
                
            if(counter < 10)
            {
                Instantiate(unit, spawnPoint.transform.position, Quaternion.identity);
                counter++;
            }

            StartCoroutine(spawnUnits());
        }
    }

    // Update is called once per frame
    void Update()
    {
        slider.value = health;

        if (health < maxHealth)
        {
            healthBarUI.SetActive(true);
        }

        if (health <= 0)
        {
            Destroy(this);
        }

        if (health >= maxHealth)
        {
            health = maxHealth;
        }
    }

} // Class end
