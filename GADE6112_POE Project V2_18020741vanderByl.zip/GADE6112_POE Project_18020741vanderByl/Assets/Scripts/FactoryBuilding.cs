﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FactoryBuilding : MonoBehaviour
{

    [SerializeField] string team;
    [SerializeField] GameObject resourceBuilding;
    [SerializeField] GameObject[] unitTypes;
    [SerializeField] GameObject spawnPoint;
    [SerializeField] float maxHealth;
    [SerializeField] float health;

    public GameObject healthBarUI;
    public Slider slider;

    private System.Random rand = new System.Random();

    // Start is called before the first frame update
    void Start()
    {
        health = maxHealth;
        slider.value = health;

        StartCoroutine(spawnUnits(rand.Next(0, unitTypes.Length)));

        IEnumerator spawnUnits(int type)
        {
            yield return new WaitForSeconds(UnityEngine.Random.Range(5f, 10f));

            if (health >= 0 && resourceBuilding.GetComponent<ResourceBuilding>().remainingResources >= 10)
            {
                Instantiate(unitTypes[type], spawnPoint.transform.position, Quaternion.identity);
                resourceBuilding.GetComponent<ResourceBuilding>().remainingResources -= 10;
            }

            StartCoroutine(spawnUnits(rand.Next(0, unitTypes.Length)));
        }
    }

    // Update is called once per frame
    void Update()
    {
        slider.value = health;

        if (health < maxHealth)
        {
            healthBarUI.SetActive(true);
        }

        if (health <= 0)
        {
            Destroy(this);
        }

        if (health >= maxHealth)
        {
            health = maxHealth;
        }
    }

} // Class end
